package com.example.demobank.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Akun{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "clientid", referencedColumnName = "id")
    private Client client; // Owner dari akun

    @NotNull
    private String idakun; // ID akun dari client

    @NotNull
    @Size(min = 6, max = 6)
    private String PIN; // PIN akun

    private int saldo; // Saldo di dalam akun client

    public Akun() {}
    public Akun(Client client, String id, String PIN, int sal) {
        this.client = client;
        this.idakun = id;
        this.PIN = PIN;
        this.saldo = sal;
    }

    // Method class akun
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Client getClient() {
        return client;
    }
    public void setClient(Client client) {
        this.client = client;
    }

    public String getIdakun() {
        return idakun;
    }
    public void setIdakun(String idakun) {
        this.idakun = idakun;
    }

    public String getPIN() {
        return PIN;
    }
    public void setPIN(String pIN) {
        PIN = pIN;
    }

    public int getSaldo() {
        return saldo;
    }
    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }
}
