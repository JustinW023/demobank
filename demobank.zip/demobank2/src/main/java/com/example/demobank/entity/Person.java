package com.example.demobank.entity;

import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "role", discriminatorType = DiscriminatorType.STRING)
public abstract class Person {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

    @ManyToOne
    @JoinColumn(name = "bankid", referencedColumnName = "id")
    protected Bank bankent;

    @NotNull
    @Size(min = 8, max = 8)
    protected String userid; // User id untuk Client dan Admin

    @NotNull
    @Size(max = 30)
    protected String name; // Nama untuk Client dan Admin

    public Person() {}
    public Person(Bank bankent, String userid, String name) {
        this.bankent = bankent;
        this.userid = userid;
        this.name = name;
    }

    // Method abstract class Person
    public abstract Long getId();
    public abstract void setId(Long id);
    public abstract Bank getBankent();
    public abstract void setBankent(Bank bankent);
    public abstract String getUserid();
    public abstract void setUserid(String userid);
    public abstract String getName();
    public abstract void setName(String name);
}
