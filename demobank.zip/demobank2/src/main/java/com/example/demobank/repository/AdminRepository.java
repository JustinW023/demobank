package com.example.demobank.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demobank.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long> {
    Admin findByUserid(String userid);
}
