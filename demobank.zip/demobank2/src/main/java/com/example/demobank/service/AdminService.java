package com.example.demobank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demobank.entity.Admin;
import com.example.demobank.repository.AdminRepository;

@Service
public class AdminService {
    @Autowired
    private AdminRepository adminRepository;

    public List<Admin> getAllAdmin() {
        return adminRepository.findAll();
    }

    public Admin addAdmin(Admin obj) {
        Long id = null;
        obj.setId(id);
        return adminRepository.save(obj);
    }

    public Admin getAdminById(long id) {
        return adminRepository.findById(id).orElse(null);
    }

    public Admin getAdminByKode(String kode) {
        return adminRepository.findByUserid(kode);
    }

    public Admin updateAdmin(long id, Admin obj) {
        obj.setId(id);
        return adminRepository.save(obj);
    }

    public void deleteAdmin(long id) {
        adminRepository.deleteById(id);
    }
}