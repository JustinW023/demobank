package com.example.demobank.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.NotNull;

@Entity
public class Loans {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private String idloan; // ID unik loans

    @OneToOne
    @JoinColumn(name = "clientid", referencedColumnName = "id")
    private Client client; // Owner dari akun

    private int amount; // Loan amount

    public Loans() {}
    public Loans(String idloan, Client client, int amount) {
        this.idloan = idloan;
        this.client = client;
        this.amount = amount;
    }

    // Method class loans
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getIdloan() {
        return idloan;
    }
    public void setIdloan(String idloan) {
        this.idloan = idloan;
    }

    public Client getClient() {
        return client;
    }
    public void setClient(Client client) {
        this.client = client;
    }

    public int getAmount() {
        return amount;
    }
    public void setAmount(int amount) {
        this.amount = amount;
    }
}
