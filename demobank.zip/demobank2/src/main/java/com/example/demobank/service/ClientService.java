package com.example.demobank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demobank.entity.Client;
import com.example.demobank.repository.ClientRepository;

@Service
public class ClientService {
    @Autowired
    private ClientRepository clientRepository;

    public List<Client> getAllClient() {
        return clientRepository.findAll();
    }

    public Client addClient(Client obj) {
        Long id = null;
        obj.setId(id);
        return clientRepository.save(obj);
    }

    public Client getClientById(long id) {
        return clientRepository.findById(id).orElse(null);
    }

    public Client getClientByKode(String kode) {
        return clientRepository.findByUserid(kode);
    }

    public Client updateClient(long id, Client obj) {
        obj.setId(id);
        return clientRepository.save(obj);
    }

    public void deleteClient(long id) {
        clientRepository.deleteById(id);
    }
}