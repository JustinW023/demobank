package com.example.demobank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demobank.entity.Divisi;
import com.example.demobank.repository.DivisiRepository;

@Service
public class DivisiService {
    @Autowired
    private DivisiRepository divisiRepository;

    public List<Divisi> getAllDivisi() {
        return divisiRepository.findAll();
    }

    public Divisi addDivisi(Divisi obj) {
        Long id = null;
        obj.setId(id);
        return divisiRepository.save(obj);
    }

    public Divisi getDivisiById(long id) {
        return divisiRepository.findById(id).orElse(null);
    }

    public Divisi updateDivisi(long id, Divisi obj) {
        obj.setId(id);
        return divisiRepository.save(obj);
    }

    public void deleteDivisi(long id) {
        divisiRepository.deleteById(id);
    }
}
