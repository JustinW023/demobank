package com.example.demobank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demobank.entity.Akun;
import com.example.demobank.repository.AkunRepository;

@Service
public class AkunService {
    @Autowired
    private AkunRepository akunRepository;

    public List<Akun> getAllAkun() {
        return akunRepository.findAll();
    }

    public Akun addAkun(Akun obj) {
        Long id = null;
        obj.setId(id);
        return akunRepository.save(obj);
    }

    public Akun getAkunById(long id) {
        return akunRepository.findById(id).orElse(null);
    }

    public Akun getAkunByClientid(Long id) {
        return akunRepository.findByClientId(id);
    }

    public Akun updateAkun(long id, Akun obj) {
        obj.setId(id);
        return akunRepository.save(obj);
    }

    public void deleteAkun(long id) {
        akunRepository.deleteById(id);
    }
}