package com.example.demobank.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demobank.entity.Branch;

public interface BranchRepository extends JpaRepository<Branch, Long> {
    
}
