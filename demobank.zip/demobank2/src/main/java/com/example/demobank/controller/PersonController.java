package com.example.demobank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demobank.entity.Person;
import com.example.demobank.entity.Admin;
import com.example.demobank.entity.Bank;
import com.example.demobank.entity.Branch;
import com.example.demobank.entity.Client;
import com.example.demobank.entity.Divisi;
import com.example.demobank.service.PersonService;
import com.example.demobank.service.AdminService;
import com.example.demobank.service.BankService;
import com.example.demobank.service.BranchService;
import com.example.demobank.service.ClientService;
import com.example.demobank.service.DivisiService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class PersonController {
    @Autowired
    private PersonService personService;

    @Autowired
    private ClientService clientService;

    @Autowired
    private AdminService adminService;

    @Autowired
    private BranchService branchService;

    @Autowired
    private DivisiService divisiService;

    @Autowired
    private BankService bankService;

    // PERSON AREA //
    @GetMapping(value = { "/person", "/person/" })
    public String personPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Person> personList = personService.getAllPerson();
            model.addAttribute("personList", personList);
            return "person.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/person/{id}")
    public String personGetRec(Model model, @PathVariable("id") Long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Person> personList = personService.getAllPerson();
            Person personRec = personService.getPersonById(id);
            model.addAttribute("personList", personList);
            model.addAttribute("personRec", personRec);
            return "person.html";
        } else {
            return "redirect:/login";
        }
    }
    // PERSON AREA //

    // CLIENT AREA //
    @GetMapping(value = { "/client", "/client/" })
    public String clientPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Client> clientList = clientService.getAllClient();
            List<Bank> bankList = bankService.getAllBank();
            model.addAttribute("clientList", clientList);
            model.addAttribute("bankList", bankList);
            model.addAttribute("clientInfo", new Client());
            return "client.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/client/{id}")
    public String clientGetRec(Model model, @PathVariable("id") Long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Client> clientList = clientService.getAllClient();
            List<Bank> bankList = bankService.getAllBank();
            Client clientRec = clientService.getClientById(id);
            model.addAttribute("clientList", clientList);
            model.addAttribute("bankList", bankList);
            model.addAttribute("clientRec", clientRec);
            return "client.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/selflook")
    public String selfLook(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Client") != null) {
            model.addAttribute("logClient", request.getSession().getAttribute("Client"));
            model.addAttribute("logAkun", request.getSession().getAttribute("Akun"));
            return "selflook.html";
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping(value = { "/client/submit/", "/client/submit/{id}" }, params = { "add" })
    public String clientAdd(@ModelAttribute("clientInfo") Client clientInfo) {
        clientService.addClient(clientInfo);
        return "redirect:/client";
    }

    @PostMapping(value = "/client/submit/{id}", params = { "edit" })
    public String clientEdit(@ModelAttribute("clientInfo") Client clientInfo, @PathVariable("id") Long id) {
        clientService.updateClient(id, clientInfo);
        return "redirect:/client";
    }

    @PostMapping(value = "/client/submit/{id}", params = { "delete" })
    public String clientDelete(@PathVariable("id") Long id) {
        clientService.deleteClient(id);
        return "redirect:/client";
    }
    // CLIENT AREA//
    
    // ADMIN AREA //
    @GetMapping(value = { "/admin", "/admin/" })
    public String adminPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Admin> adminList = adminService.getAllAdmin();
            List<Bank> bankList = bankService.getAllBank();
            List<Branch> branchList = branchService.getAllBranch();
            List<Divisi> divisiList = divisiService.getAllDivisi();
            model.addAttribute("adminList", adminList);
            model.addAttribute("bankList", bankList);
            model.addAttribute("branchList", branchList);
            model.addAttribute("divisiList", divisiList);
            model.addAttribute("adminInfo", new Admin());
            return "admin.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/admin/{id}")
    public String adminGetRec(Model model, @PathVariable("id") Long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Admin> adminList = adminService.getAllAdmin();
            List<Bank> bankList = bankService.getAllBank();
            List<Branch> branchList = branchService.getAllBranch();
            List<Divisi> divisiList = divisiService.getAllDivisi();
            Admin adminRec = adminService.getAdminById(id);
            model.addAttribute("adminList", adminList);
            model.addAttribute("bankList", bankList);
            model.addAttribute("branchList", branchList);
            model.addAttribute("divisiList", divisiList);
            model.addAttribute("adminRec", adminRec);
            return "admin.html";
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping(value = { "/admin/submit/", "/admin/submit/{id}" }, params = { "add" })
    public String adminAdd(@ModelAttribute("adminInfo") Admin adminInfo) {
        if (adminInfo.getBankent().getId() == adminInfo.getBranch().getBankent().getId() && adminInfo.getDivisi().getBranch().getId() == adminInfo.getBranch().getId()) {
            adminService.addAdmin(adminInfo);
        } else {
            System.err.println("DATA INCONSISTENT, ADMIN NOT ADDED");
        }
        return "redirect:/admin";
    }

    @PostMapping(value = "/admin/submit/{id}", params = { "edit" })
    public String adminEdit(@ModelAttribute("adminInfo") Admin adminInfo, @PathVariable("id") Long id) {
        adminService.updateAdmin(id, adminInfo);
        return "redirect:/admin";
    }

    @PostMapping(value = "/admin/submit/{id}", params = { "delete" })
    public String adminDelete(@PathVariable("id") Long id) {
        adminService.deleteAdmin(id);
        return "redirect:/admin";
    }

    @GetMapping("/selflookadmin")
    public String selfLookAdmin(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            model.addAttribute("logAdmin", request.getSession().getAttribute("Admin"));
            model.addAttribute("logBranch", request.getSession().getAttribute("Branch"));
            model.addAttribute("logDivisi", request.getSession().getAttribute("Divisi"));
            return "selflookadmin.html";
        } else {
            return "redirect:/login";
        }
    }
    // ADMIN AREA //
}
