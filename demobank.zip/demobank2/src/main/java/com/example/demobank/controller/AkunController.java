package com.example.demobank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demobank.entity.Akun;
import com.example.demobank.entity.Client;
import com.example.demobank.service.AkunService;
import com.example.demobank.service.ClientService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class AkunController {
    @Autowired
    private AkunService akunService;

    @Autowired
    private ClientService clientService;

    @GetMapping(value = { "/akun", "/akun/" })
    public String akunPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Akun> akunList = akunService.getAllAkun();
            model.addAttribute("akunList", akunList);
            model.addAttribute("akunInfo", new Akun());
            return "akun.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping(value = "/akun/{id}")
    public String akunGetRec(Model model, @PathVariable("id") Long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Akun> akunList = akunService.getAllAkun();
            Akun akunRec = akunService.getAkunById(id);
            model.addAttribute("akunList", akunList);
            model.addAttribute("akunRec", akunRec);
            return "akun.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping(value = { "/makeakun", "/makeakun/" })
    public String akunClientPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Client") != null) {
            List<Akun> akunList = akunService.getAllAkun();
            Client C = (Client)request.getSession().getAttribute("Client");
            model.addAttribute("clientRec", C);
            model.addAttribute("akunList", akunList);
            model.addAttribute("akunInfo", new Akun());
            return "makeakun.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping(value = "/saldoinfo")
    public String saldoInfo(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            model.addAttribute("logClient", request.getSession().getAttribute("Client"));
            model.addAttribute("logAkun", request.getSession().getAttribute("Akun"));
            return "saldoinfo.html";
        } else {
            return "redirect:/akunlogin";
        }
    }

    @GetMapping(value = "/deposit")
    public String depositMenu(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            model.addAttribute("logAkun", request.getSession().getAttribute("Akun"));
            return "deposit.html";
        } else {
            return "redirect:/akunlogin";
        }
    }

    @GetMapping(value = "/withdraw")
    public String withdrawMenu(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            model.addAttribute("logAkun", request.getSession().getAttribute("Akun"));
            return "withdraw.html";
        } else {
            return "redirect:/akunlogin";
        }
    }
    
    @PostMapping(value = "/depositsend")
    public String akunDeposit(@RequestParam("amount") int amount, @RequestParam("id") long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            Akun AK = (Akun)request.getSession().getAttribute("Akun");
            int temp = AK.getSaldo() + amount;
            AK.setSaldo(temp);
            akunService.updateAkun(id, AK);
            request.getSession().setAttribute("Akun", AK);
            return "redirect:/akunmenu";
        } else {
            return "redirect:/akunlogin";
        }
    }

    @PostMapping(value = "/withdrawsend")
    public String akunWithdraw(@RequestParam("amount") int amount, @RequestParam("id") long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            Akun AK = (Akun)request.getSession().getAttribute("Akun");
            int temp = AK.getSaldo();
            if (temp - amount < 0) {
                System.err.println("Amount not enough");
                return "redirect:/akunmenu";
            } else {
                int temp2 = temp - amount;
                AK.setSaldo(temp2);
                akunService.updateAkun(id, AK);
                request.getSession().setAttribute("Akun", AK);
                return "redirect:/akunmenu";
            }
        } else {
            return "redirect:/akunlogin";
        }
    }

    @PostMapping(value = { "/akunclient/submit/", "/akunclient/submit/{id}" }, params = { "add" })
    public String akunClientAdd(@ModelAttribute("akunInfo") Akun akunInfo, @RequestParam("clientid") long clientid, HttpServletRequest request) {
        try {
            Integer.parseInt(akunInfo.getPIN());
        } catch (NumberFormatException e) {
            System.err.println("ERROR parsing int");
            return "redirect:/makeakun";
        }
        Client C = clientService.getAllClient().stream().filter(c -> (c.getId()).equals(clientid)).findFirst().orElse(null);
        akunInfo.setClient(C);
        akunService.addAkun(akunInfo);
        request.getSession().setAttribute("Akun", akunInfo);
        request.getSession().setAttribute("Akuntemp", akunInfo);
        return "redirect:/akunmenu";
    }
}