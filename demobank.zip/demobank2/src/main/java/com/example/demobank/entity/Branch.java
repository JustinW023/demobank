package com.example.demobank.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Branch {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "bankid", referencedColumnName = "id")
    private Bank bankent;

    @NotNull
    @Size(min = 8, max = 8)
    private String idbranch;

    @NotNull
    @Size(max = 30)
    private String name;

    public Branch() {}
    public Branch(Bank bankent, String idbranch, String name) {
        this.bankent = bankent;
        this.idbranch = idbranch;
        this.name = name;
    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Bank getBankent() {
        return bankent;
    }
    public void setBankent(Bank bankent) {
        this.bankent = bankent;
    }

    public String getIdbranch() {
        return idbranch;
    }
    public void setIdbranch(String idbranch) {
        this.idbranch = idbranch;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}
