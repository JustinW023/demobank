package com.example.demobank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demobank.entity.Branch;
import com.example.demobank.repository.BranchRepository;

@Service
public class BranchService {
    @Autowired
    private BranchRepository branchRepository;

    public List<Branch> getAllBranch() {
        return branchRepository.findAll();
    }

    public Branch addBranch(Branch obj) {
        Long id = null;
        obj.setId(id);
        return branchRepository.save(obj);
    }

    public Branch getBranchById(long id) {
        return branchRepository.findById(id).orElse(null);
    }

    public Branch updateBranch(long id, Branch obj) {
        obj.setId(id);
        return branchRepository.save(obj);
    }

    public void deleteBranch(long id) {
        branchRepository.deleteById(id);
    }
}
