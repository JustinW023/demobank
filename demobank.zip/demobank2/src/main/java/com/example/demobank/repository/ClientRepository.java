package com.example.demobank.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demobank.entity.Client;

public interface ClientRepository extends JpaRepository<Client, Long> {
    Client findByUserid(String userid);
}
