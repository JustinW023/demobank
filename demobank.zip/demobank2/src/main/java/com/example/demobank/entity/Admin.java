package com.example.demobank.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotNull;

@Entity
public class Admin extends Person{
    @NotNull
    private String password; // Password untuk admin

    @ManyToOne
    @JoinColumn(name = "branchid", referencedColumnName = "id")
    private Branch branch; // Divisi admin diambil dari entity divisi

    @ManyToOne
    @JoinColumn(name = "divisiid", referencedColumnName = "id")
    private Divisi divisi; // Divisi admin diambil dari entity divisi

    public Admin() {}
    public Admin (Bank bankent, String userid, String name, String pass, Divisi divisi) {
        super(bankent, userid, name);
        this.password = pass;
        this.divisi = divisi;
    }

    // Method class abstract person
    @Override
    public Long getId() {
        return id;
    }
    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public Bank getBankent() {
        return bankent;
    }
    @Override
    public void setBankent(Bank bankent) {
        this.bankent = bankent;
    }

    @Override
    public String getUserid() {
        return userid;
    }
    @Override
    public void setUserid(String userid) {
        this.userid = userid;
    }

    @Override
    public String getName() {
        return name;
    }
    @Override
    public void setName(String name) {
        this.name = name;
    }

    // Method class admin
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public Branch getBranch() {
        return branch;
    }
    public void setBranch(Branch branch) {
        this.branch = branch;
    }

    public Divisi getDivisi() {
        return divisi;
    }
    public void setDivisi(Divisi divisi) {
        this.divisi = divisi;
    }
}
