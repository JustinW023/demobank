package com.example.demobank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demobank.entity.Admin;
import com.example.demobank.entity.Akun;
import com.example.demobank.entity.Branch;
import com.example.demobank.entity.Client;
import com.example.demobank.entity.Divisi;
import com.example.demobank.entity.Loans;
import com.example.demobank.service.*;
import org.springframework.ui.Model;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class MenuController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private BranchService branchService;

    @Autowired
    private DivisiService divisiService;

    @Autowired
    private ClientService clientService;

    @Autowired
    private AkunService akunService;

    @Autowired
    private LoansService loansService;

    MenuController(BranchService branchService) {
        this.branchService = branchService;
    }

    @GetMapping("/")
    public String home() {
        return "home.html";
    }

    @GetMapping("/clientmenu")
    public String clientPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Client") != null) {
            model.addAttribute("logClient", request.getSession().getAttribute("Client"));
            model.addAttribute("logAkun", request.getSession().getAttribute("Akun"));
            return "clientmenu.html";
        } else {
            return "redirect:/login";
        }
    }
    
    @GetMapping("/adminmenu")
    public String adminPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            model.addAttribute("logAdmin", request.getSession().getAttribute("Admin"));
            return "adminmenu.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/akunmenu")
    public String akunClient(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            model.addAttribute("logClient", request.getSession().getAttribute("Client"));
            model.addAttribute("logAkun", request.getSession().getAttribute("Akun"));
            model.addAttribute("logLoans", request.getSession().getAttribute("Loans"));
            return "akunmenu.html";
        } else {
            return "redirect:/akunlogin";
        }
    }

    @GetMapping("/login")
    public String loginPage(HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            return "redirect:/adminmenu";
        } else if (request.getSession().getAttribute("Client") != null) {
            return "redirect:/clientmenu";
        } else {
            return "login.html";
        }
    }
    
    @PostMapping("/loginvalidate")
    public String validateLogin(Model model, @RequestParam(value = "kode") String kode, @RequestParam(value = "password") String password, HttpServletRequest request) {
        Admin A = null;
        Client C = null;
        A = adminService.getAdminByKode(kode);
        C = clientService.getClientByKode(kode);
        if (A != null) {
            model.addAttribute("userRec", A);
            if ((A.getPassword()).equals(password)) {
                Branch B = null;
                Divisi D = null;
                B = branchService.getBranchById(A.getId());
                D = divisiService.getDivisiById(A.getId());
                request.getSession().setAttribute("Admin", A);
                request.getSession().setAttribute("Branch", B);
                request.getSession().setAttribute("Divisi", D);
                model.addAttribute("userRec", A);
                return "redirect:/adminmenu";
            } else {
                return "redirect:/login";
            }
        } else if (C != null) {
            model.addAttribute("userRec", C);
            if ((C.getPassword()).equals(password)) {
                Akun AK = null;
                Loans L = null;
                AK = akunService.getAkunByClientid((C.getId()));
                L = loansService.getLoansByClientid((C.getId()));
                request.getSession().setAttribute("Client", C);
                request.getSession().setAttribute("Akun", AK);
                request.getSession().setAttribute("Loans", L);
                model.addAttribute("userRec", C);
                return "redirect:/clientmenu";
            } else {
                return "redirect:/login";
            }
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/akunlogin")
    public String akunLogin(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Client") != null) {
            if (request.getSession().getAttribute("Akuntemp") != null) {
                return "redirect:/akunmenu";
            } else {
                model.addAttribute("logAkun", request.getSession().getAttribute("Akun"));
                return "akunlogin.html";
            }
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping("/akunvalidate")
    public String akunValidate(Model model, @RequestParam(value = "kode") String kode, @RequestParam(value = "password") String password, HttpServletRequest request) {
        Long temp = null;
        try { temp = Long.parseLong(kode); } catch (Exception E) {System.err.println("Error parsing kode"); return "redirect:/clientmenu";}
        Akun A = akunService.getAkunById(temp);
        if ((A.getPIN()).equals(password)) {
            request.getSession().setAttribute("Akuntemp", A);
            return "redirect:/akunmenu";
        } else {
            return "redirect:/clientmenu";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null || request.getSession().getAttribute("Client") != null) {
            request.getSession().invalidate();
        }
        return "redirect:/login";
    }
}
