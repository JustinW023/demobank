package com.example.demobank.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demobank.entity.Divisi;

public interface DivisiRepository extends JpaRepository<Divisi, Long> {
    
}
