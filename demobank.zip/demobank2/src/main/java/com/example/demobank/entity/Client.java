package com.example.demobank.entity;

import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Client extends Person{
    @NotNull
    private String password; // Password untuk client

    @NotNull
    @Size(max = 6)
    private String gender; // Jenis kelamin client

    @NotNull
    private int age; // Umur dari client

    public Client() {}
    public Client(Bank bankent, String userid, String name, String password, String gender, int age) {
        super(bankent, userid, name);
        this.password = password;
        this.gender = gender;
        this.age = age;
    }

    // Method class abstract person
    @Override
    public Long getId() {
        return id;
    }
    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public Bank getBankent() {
        return bankent;
    }
    @Override
    public void setBankent(Bank bankent) {
        this.bankent = bankent;
    }

    @Override
    public String getUserid() {
        return userid;
    }
    @Override
    public void setUserid(String userid) {
        this.userid = userid;
    }

    @Override
    public String getName() {
        return name;
    }
    @Override
    public void setName(String name) {
        this.name = name;
    }

    // Method class client
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
}
