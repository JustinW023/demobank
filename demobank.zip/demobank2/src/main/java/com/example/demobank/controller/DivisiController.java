package com.example.demobank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demobank.entity.Branch;
import com.example.demobank.entity.Divisi;
import com.example.demobank.service.BranchService;
import com.example.demobank.service.DivisiService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class DivisiController {
    @Autowired
    private DivisiService divisiService;

    @Autowired
    private BranchService branchService;

    @GetMapping(value = { "/divisi", "/divisi/" })
    public String divisiPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Divisi> divisiList = divisiService.getAllDivisi();
            List<Branch> branchList = branchService.getAllBranch();
            model.addAttribute("divisiList", divisiList);
            model.addAttribute("branchList", branchList);
            model.addAttribute("divisiInfo", new Divisi());
            return "divisi.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping(value = "/divisi/{id}")
    public String divisiGetRec(Model model, @PathVariable("id") Long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Divisi> divisiList = divisiService.getAllDivisi();
            List<Branch> branchList = branchService.getAllBranch();
            Divisi divisiRec = divisiService.getDivisiById(id);
            model.addAttribute("divisiList", divisiList);
            model.addAttribute("branchList", branchList);
            model.addAttribute("divisiRec", divisiRec);
            return "divisi.html";
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping(value = { "/divisi/submit/", "/divisi/submit/{id}" }, params = { "add" })
    public String divisiAdd(@ModelAttribute("divisiInfo") Divisi divisiInfo) {
        divisiService.addDivisi(divisiInfo);
        return "redirect:/divisi";
    }

    @PostMapping(value = "/divisi/submit/{id}", params = { "edit" })
    public String divisiEdit(@ModelAttribute("divisiInfo") Divisi divisiInfo, @PathVariable("id") Long id) {
        divisiService.updateDivisi(id, divisiInfo);
        return "redirect:/divisi";
    }

    @PostMapping(value = "/divisi/submit/{id}", params = { "delete" })
    public String divisiDelete(@PathVariable("id") Long id) {
        divisiService.deleteDivisi(id);
        return "redirect:/divisi";
    }
}