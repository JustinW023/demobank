package com.example.demobank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demobank.entity.Loans;
import com.example.demobank.repository.LoansRepository;

@Service
public class LoansService {
    @Autowired
    private LoansRepository loansRepository;

    public List<Loans> getAllLoans() {
        return loansRepository.findAll();
    }

    public Loans addLoans(Loans obj) {
        Long id = null;
        obj.setId(id);
        return loansRepository.save(obj);
    }

    public Loans getLoansById(long id) {
        return loansRepository.findById(id).orElse(null);
    }

    public Loans getLoansByClientid(Long id) {
        return loansRepository.findByClientId(id);
    }

    public Loans updateLoans(long id, Loans obj) {
        obj.setId(id);
        return loansRepository.save(obj);
    }

    public void deleteLoans(long id) {
        loansRepository.deleteById(id);
    }
}