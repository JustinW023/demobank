package com.example.demobank.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demobank.entity.Akun;
import com.example.demobank.entity.Client;
import com.example.demobank.entity.Loans;
import com.example.demobank.service.AkunService;
import com.example.demobank.service.ClientService;
import com.example.demobank.service.LoansService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class LoansController {
    @Autowired
    private AkunService akunService;
    
    @Autowired
    private LoansService loansService;

    @Autowired
    private ClientService clientService;

    @GetMapping(value = { "/loans", "/loans/" })
    public String loansPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Loans> loansList = loansService.getAllLoans();
            model.addAttribute("loansList", loansList);
            model.addAttribute("loansInfo", new Loans());
            return "loans.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping(value = "/loans/{id}")
    public String loansGetRec(Model model, @PathVariable("id") Long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Loans> loansList = loansService.getAllLoans();
            Loans loansRec = loansService.getLoansById(id);
            model.addAttribute("loansList", loansList);
            model.addAttribute("loansRec", loansRec);
            return "loans.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/makeloans")
    public String loansClientPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            List<Loans> loansList = loansService.getAllLoans();
            Client C = (Client)request.getSession().getAttribute("Client");
            model.addAttribute("clientRec", C);
            model.addAttribute("loansList", loansList);
            model.addAttribute("loansInfo", new Loans());
            return "makeloans.html";
        } else {
            return "redirect:/akunlogin";
        }
    }

    @PostMapping(value = { "/makeloans/submit/", "/makeloans/submit/{id}" }, params = { "add" })
    public String loansClientAdd(@ModelAttribute("loansInfo") Loans loansInfo, @RequestParam("clientid") long clientid, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            Akun AK = (Akun)request.getSession().getAttribute("Akun");
            Client C = clientService.getAllClient().stream().filter(c -> (c.getId()).equals(clientid)).findFirst().orElse(null);
            long id = AK.getId();
            int temp = AK.getSaldo() + loansInfo.getAmount();
            loansInfo.setClient(C);
            loansInfo.setIdloan(UUID.randomUUID().toString());
            AK.setSaldo(temp);
            loansService.addLoans(loansInfo);
            akunService.updateAkun(id, AK);
            request.getSession().setAttribute("Akun", AK);
            request.getSession().setAttribute("Loans", loansInfo);
            return "redirect:/akunmenu";
        } else {
            return "redirect:/akunlogin";
        }
    }

    @GetMapping("/loaninfo")
    public String loanInfo(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            model.addAttribute("logLoans", request.getSession().getAttribute("Loans"));
            return "loaninfo.html";
        } else {
            return "redirect:/akunlogin";
        }
    }

    @GetMapping("/payloans")
    public String payLoans(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            model.addAttribute("clientRec", request.getSession().getAttribute("Client"));
            return "payloans.html";
        } else {
            return "redirect:/akunlogin";
        }
    }

    @PostMapping(value = "/payingloans")
    public String loansWithdraw(@RequestParam("amount") String amount, HttpServletRequest request) {
        if (request.getSession().getAttribute("Akuntemp") != null) {
            int amountt = Integer.parseInt(amount);
            Akun AK = (Akun)request.getSession().getAttribute("Akun");
            Loans L = (Loans)request.getSession().getAttribute("Loans");
            int temp = L.getAmount();
            int temp2 = AK.getSaldo();
            int temp3;
            if (amountt > temp) {
                if (temp2 - temp >= 0) {
                    temp3 = temp2 - temp;
                    AK.setSaldo(temp3);
                } else {
                    System.err.println("Saldo not enough");
                    return "redirect:/akunmenu";
                }
                akunService.updateAkun(AK.getId(), AK);
                loansService.deleteLoans(L.getId());
                request.getSession().setAttribute("Akun", AK);
                request.getSession().setAttribute("Loans", null);
                return "redirect:/akunmenu";
            } else {
                if (temp2 - amountt >= 0) {
                    temp3 = temp2 - amountt;
                    AK.setSaldo(temp3);
                    temp3 = temp - amountt;
                    L.setAmount(temp3);
                } else {
                    System.err.println("Saldo not enough");
                    return "redirect:/akunmenu";
                }
                akunService.updateAkun(AK.getId(), AK);
                loansService.updateLoans(L.getId(), L);
                request.getSession().setAttribute("Akun", AK);
                request.getSession().setAttribute("Loans", L);
                return "redirect:/akunmenu";
            }
        } else {
            return "redirect:/akunlogin";
        }
    }
}
