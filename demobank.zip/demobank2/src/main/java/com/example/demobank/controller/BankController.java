package com.example.demobank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demobank.entity.Bank;
import com.example.demobank.service.BankService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class BankController {
    @Autowired
    private BankService bankService;

    @GetMapping(value = { "/bank", "/bank/" })
    public String bankPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Bank> bankList = bankService.getAllBank();
            model.addAttribute("bankList", bankList);
            model.addAttribute("bankInfo", new Bank());
            return "bank.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/bank/{id}")
    public String bankGetRec(Model model, @PathVariable("id") Long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Bank> bankList = bankService.getAllBank();
            Bank bankRec = bankService.getBankById(id);
            model.addAttribute("bankList", bankList);
            model.addAttribute("bankRec", bankRec);
            return "bank.html";
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping(value = { "/bank/submit/", "/bank/submit/{id}" }, params = { "add" })
    public String bankAdd(@ModelAttribute("bankInfo") Bank bankInfo) {
        bankService.addBank(bankInfo);
        return "redirect:/bank";
    }

    @PostMapping(value = "/bank/submit/{id}", params = { "edit" })
    public String bankEdit(@ModelAttribute("bankInfo") Bank bankInfo, @PathVariable("id") Long id) {
        bankService.updateBank(id, bankInfo);
        return "redirect:/bank";
    }

    @PostMapping(value = "/bank/submit/{id}", params = { "delete" })
    public String bankDelete(@PathVariable("id") Long id) {
        bankService.deleteBank(id);
        return "redirect:/bank";
    }
}
