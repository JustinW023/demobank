package com.example.demobank.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demobank.entity.Akun;

public interface AkunRepository extends JpaRepository<Akun, Long> {
    Akun findByClientId(Long id);
}
