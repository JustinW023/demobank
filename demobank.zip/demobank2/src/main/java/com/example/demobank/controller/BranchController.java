package com.example.demobank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demobank.entity.Bank;
import com.example.demobank.entity.Branch;
import com.example.demobank.service.BankService;
import com.example.demobank.service.BranchService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class BranchController {
    @Autowired
    private BranchService branchService;

    @Autowired
    private BankService bankService;

    @GetMapping(value = { "/branch", "/branch/" })
    public String branchPage(Model model, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Branch> branchList = branchService.getAllBranch();
            List<Bank> bankList = bankService.getAllBank();
            model.addAttribute("branchList", branchList);
            model.addAttribute("bankList", bankList);
            model.addAttribute("branchInfo", new Branch());
            return "branch.html";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping(value = "/branch/{id}")
    public String branchGetRec(Model model, @PathVariable("id") Long id, HttpServletRequest request) {
        if (request.getSession().getAttribute("Admin") != null) {
            List<Branch> branchList = branchService.getAllBranch();
            List<Bank> bankList = bankService.getAllBank();
            Branch branchRec = branchService.getBranchById(id);
            model.addAttribute("branchList", branchList);
            model.addAttribute("bankList", bankList);
            model.addAttribute("branchRec", branchRec);
            return "branch.html";
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping(value = { "/branch/submit/", "/branch/submit/{id}" }, params = { "add" })
    public String branchAdd(@ModelAttribute("branchInfo") Branch branchInfo) {
        branchService.addBranch(branchInfo);
        return "redirect:/branch";
    }

    @PostMapping(value = "/branch/submit/{id}", params = { "edit" })
    public String branchEdit(@ModelAttribute("branchInfo") Branch branchInfo, @PathVariable("id") Long id) {
        branchService.updateBranch(id, branchInfo);
        return "redirect:/branch";
    }

    @PostMapping(value = "/branch/submit/{id}", params = { "delete" })
    public String branchDelete(@PathVariable("id") Long id) {
        branchService.deleteBranch(id);
        return "redirect:/branch";
    }
}