package com.example.demobank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demobank.entity.Bank;
import com.example.demobank.repository.BankRepository;

@Service
public class BankService {
    @Autowired
    private BankRepository bankRepository;

    public List<Bank> getAllBank() {
        return bankRepository.findAll();
    }

    public Bank addBank(Bank obj) {
        Long id = null;
        obj.setId(id);
        return bankRepository.save(obj);
    }

    public Bank getBankById(long id) {
        return bankRepository.findById(id).orElse(null);
    }

    public Bank updateBank(long id, Bank obj) {
        obj.setId(id);
        return bankRepository.save(obj);
    }

    public void deleteBank(long id) {
        bankRepository.deleteById(id);
    }
}