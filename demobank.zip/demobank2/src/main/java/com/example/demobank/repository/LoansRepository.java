package com.example.demobank.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demobank.entity.Loans;

public interface LoansRepository extends JpaRepository<Loans, Long> {
    Loans findByClientId(Long id);
}
