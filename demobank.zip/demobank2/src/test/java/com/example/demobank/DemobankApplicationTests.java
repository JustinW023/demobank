package com.example.demobank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemobankApplicationTests {

	@Test
	void contextLoads() {
	}

}
